<!-- <html>
<head>
    <title>Membuat Form Pendaftaran Registrasi Dengan PHP MySQL</title>    
</head>
<body>
    <h2>Form Pendaftaran Registrasi PHP MySQL</h2>
    <form action="connect_login.php" method="post">        
        <table>
            <tr>
                <td width="120">Username</td>
                <td><input type="text" name="username" id="username"></td>
            </tr>
            </tr>
            <tr>
                <td>Email</td>
                <td><input type="text" name="email" id="email"></td>
            </tr>
            <tr>
                <td>Password</td>
                <td><input type="password" name="password" id="password"></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" name="submit" value="registrasi"></td>
            </tr>
        </table>
    </form>
</body>
</html> -->
<!DOCTYPE HTML>
<html>
    <head>
        <title>Halaman Login</title>
        <link rel="stylesheet" href="connect_login.php">
    </head>
   <style>
    .container{
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%,-50%);
    padding: 20px 25px;
    width: 300px;

    
    background-image: url();
    background-repeat: no-repeat;
    background-size:cover;
    width: 20%;
    height: 50%;
    box-shadow: 0 0 10px rgba(255,255,255,.3);}

    body{
     background-image: url("https://2.bp.blogspot.com/-Weij04gvPAU/UqioqJ1FDXI/AAAAAAAACrU/IfLUPgxalAc/s1600/Latest+Dark+HD+Wallpapers+(2).jpg");
     background-repeat: no-repeat;
     background-size:cover;
     }
   </style>
   <body>
   <div class="container">
    <p>
    <a href ="register.php">klik untuk kembali</a>
    </p>
          <h1>Login</h1>
            <form action="connect_register.php" method="post">
                <label><b>
                Username
                </b></label><br>
                <input type="text" id="username" name="username"><br>
                <label><b>
                email
                </b></label><br>
                <input type="text" id="email" name="email"><br>
                <label><b>
                Password
                </b></label><br>
                <input type="text" id="password" name="password"><br>
                <br>
                <button>Log In</button>
            </form>
        </div>             
</body>
    </body>
</html>
